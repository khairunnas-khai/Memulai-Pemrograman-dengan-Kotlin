data class DataUser(val name : String, val age : Int)

fun main() {
    println("Data Class")
}